"""train_compare.py 결과로 비교 그래프와 결과표를 만든다.
사용법: python make_plots.py --res results --fig figures
"""
import argparse, glob, json, os, time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from scipy import stats
import torch

from furi_model import SteerNet, ema_sequence
from train_compare import CONFIGS, expand_train, balanced_indices, metrics, CURVE_TH

# ---- 스타일 (dataviz 기본 팔레트, 밝은 배경)
for f in font_manager.findSystemFonts():
    if "NotoSansCJK" in f.replace(" ", "") and "Regular" in f:
        font_manager.fontManager.addfont(f)
plt.rcParams.update({
    "font.family": ["Noto Sans CJK KR", "Noto Sans CJK JP", "DejaVu Sans"],
    "axes.unicode_minus": False, "font.size": 12,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#b5b4ad", "axes.labelcolor": "#52514e",
    "xtick.color": "#52514e", "ytick.color": "#52514e",
    "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.8,
    "axes.axisbelow": True, "figure.facecolor": "#fcfcfb", "axes.facecolor": "#fcfcfb",
    "savefig.facecolor": "#fcfcfb", "legend.frameon": False,
})
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#8a8983"
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]   # 슬롯 순서 고정
BASE_GRAY, BEST_BLUE, POST = "#a3a29b", "#2a78d6", "#eb6834"
ALPHAS = [1.0, 0.7, 0.5, 0.4, 0.3, 0.2]


def load_runs(res):
    runs = {c["key"]: [] for c in CONFIGS}
    for p in sorted(glob.glob(os.path.join(res, "run_*.json"))):
        r = json.load(open(p))
        runs[r["cfg"]["key"]].append(r)
    return runs


def ms(vals):
    v = np.array(vals)
    return v.mean(), v.std(ddof=1) if len(v) > 1 else 0.0


def save(fig, path):
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--res", default="results")
    ap.add_argument("--fig", default="figures")
    ap.add_argument("--final", default="D", help="후처리·시계열에 쓸 최종 설정")
    a = ap.parse_args()
    os.makedirs(a.fig, exist_ok=True)
    runs = load_runs(a.res)
    keys = [c["key"] for c in CONFIGS if runs[c["key"]]]
    names = {c["key"]: c["name"] for c in CONFIGS}
    z = np.load(os.path.join(a.res, "cache.npz"))
    X, y = z["X"], z["y"]
    split = json.load(open(os.path.join(a.res, "split.json")))
    tr, va, te = (np.array(split[k]) for k in ("train", "val", "test"))
    yte, yva = y[te], y[va]
    ref = json.load(open(os.path.join(a.res, "ref_zero.json")))
    n_seeds = min(len(runs[k]) for k in keys)

    # ------------------------------------------------ 후처리 alpha: 검증셋으로 선택
    last = a.final
    val_tab = []
    for al in ALPHAS:
        m = [metrics(yva, ema_sequence(np.array(r["pred_val"]), al), va // 100) for r in runs[last]]
        val_tab.append((al, np.mean([x["mae"] for x in m]), np.mean([x["jitter"] for x in m])))
    mae1 = val_tab[0][1]
    alpha = min(al for al, mae, _ in val_tab if mae <= mae1 * 1.05)
    post = [metrics(yte, ema_sequence(np.array(r["pred_test"]), alpha), te // 100) for r in runs[last]]

    # ------------------------------------------------ 결과표
    rows, summary = [], {}
    metric_names = [("mae", "전체 MAE"), ("mae_curve", "곡선 MAE"), ("mae_straight", "직진 MAE"),
                    ("rmse", "RMSE"), ("jitter", "흔들림")]
    def add_row(label, mlist, extra=""):
        d = {k: ms([m[k] for m in mlist]) for k, _ in metric_names}
        summary[label] = {k: dict(mean=v[0], std=v[1]) for k, v in d.items()}
        rows.append("| " + label + " | " + " | ".join(f"{d[k][0]:.4f} ± {d[k][1]:.4f}" for k, _ in metric_names) + f" | {extra} |")
    add_row("참고: 항상 직진(0) 출력", [ref], "학습 없음")
    for k in keys:
        ep = [len(r["hist"]) for r in runs[k]]
        sec = [r["train_sec"] for r in runs[k]]
        add_row(f"{k}. {names[k]}", [r["test"] for r in runs[k]], f"에폭 {np.mean(ep):.0f}, {np.mean(sec):.0f}초")
    add_row(f"{last}. + 후처리(EMA α={alpha})", post, "학습 동일, 출력만 평활")

    # 유의성: 기준(A) 대비, 바로 앞 단계 대비 (Welch t-test, 곡선 MAE)
    sig = []
    for i, k in enumerate(keys[1:], 1):
        for other in sorted({keys[0], keys[i - 1]}):
            va_ = [r["test"]["mae_curve"] for r in runs[k]]
            vb_ = [r["test"]["mae_curve"] for r in runs[other]]
            t, p = stats.ttest_ind(va_, vb_, equal_var=False)
            sig.append(f"| {k} vs {other} | {np.mean(vb_):.4f} → {np.mean(va_):.4f} | "
                       f"{(np.mean(va_)/np.mean(vb_)-1)*100:+.1f}% | p={p:.3f} |")
    jit_e = [r["test"]["jitter"] for r in runs[last]]
    jit_p = [m["jitter"] for m in post]
    t, p_post = stats.ttest_rel(jit_e, jit_p)

    # 추론 속도 (작업 공간 CPU, 참고값)
    lat = {}
    for th in (1, 2):
        torch.set_num_threads(th)
        net = SteerNet().eval()
        x = torch.zeros(1, 3, 48, 128)
        with torch.no_grad():
            for _ in range(20): net(x)
            t0 = time.perf_counter()
            for _ in range(200): net(x)
        lat[th] = (time.perf_counter() - t0) / 200 * 1000
    n_params = sum(p.numel() for p in SteerNet().parameters())

    with open(os.path.join(a.fig, "results.md"), "w") as f:
        f.write(f"# 결과표 (시험셋 {len(te)}프레임 중 곡선 {int((np.abs(yte)>=CURVE_TH).sum())}프레임, 시드 {n_seeds}회 평균 ± 표준편차)\n\n")
        f.write("| 설정 | " + " | ".join(n for _, n in metric_names) + " | 비고 |\n|" + "---|" * (len(metric_names) + 2) + "\n")
        f.write("\n".join(rows) + "\n\n")
        f.write("## 곡선 MAE 차이 검정 (Welch t-test)\n\n| 비교 | 평균 변화 | 변화율 | p값 |\n|---|---|---|---|\n")
        f.write("\n".join(sig) + "\n\n")
        f.write(f"## 후처리\n검증셋에서 MAE가 5% 이상 나빠지지 않는 가장 강한 평활 α={alpha} 선택.\n\n")
        f.write("| α | 검증 MAE | 검증 흔들림 |\n|---|---|---|\n" + "\n".join(f"| {al} | {m:.4f} | {j:.4f} |" for al, m, j in val_tab) + "\n\n")
        f.write(f"시험셋 흔들림 {np.mean(jit_e):.4f} → {np.mean(jit_p):.4f} ({(np.mean(jit_p)/np.mean(jit_e)-1)*100:+.0f}%, paired t-test p={p_post:.4f})\n\n")
        f.write(f"## 모델 크기·속도 (작업 공간 CPU 기준 참고값, 라즈베리파이 실측 아님)\n파라미터 {n_params:,}개, 1장 추론 1스레드 {lat[1]:.2f}ms / 2스레드 {lat[2]:.2f}ms\n")
    json.dump(dict(summary=summary, alpha=alpha, latency_ms=lat, n_params=n_params),
              open(os.path.join(a.fig, "summary.json"), "w"), ensure_ascii=False, indent=1)

    # ------------------------------------------------ 그림 1: 조향값 분포
    rng = np.random.RandomState(0)
    _, ytr3, zero3 = expand_train(X, y, tr, 3)
    sel = balanced_indices(zero3, rng)
    yb = ytr3[sel]
    yb = np.concatenate([yb, -yb])   # 좌우 반전 증강 반영(기댓값)
    fig, axs = plt.subplots(1, 2, figsize=(11, 3.8), sharey=False)
    bins = np.linspace(-1, 1, 41)
    for ax, data, title, col in [(axs[0], y[tr], "개선 전: 중앙 카메라 원본", BASE_GRAY),
                                 (axs[1], yb, "개선 후: 좌우 카메라 + 반전 + 균형화", BEST_BLUE)]:
        w = np.ones_like(data) / len(data) * 100
        ax.hist(data, bins=bins, weights=w, color=col, edgecolor="#fcfcfb", linewidth=1)
        ax.set_title(title, color=INK, loc="left", fontsize=13)
        ax.set_xlabel("조향값 (-1 왼쪽 ~ +1 오른쪽)")
        ax.set_ylabel("프레임 비율 (%)")
        zshare = (np.abs(data) < 0.01).mean() * 100
        ax.text(0.98, 0.92, f"직진(0) 비율 {zshare:.0f}%\n표본 {len(data):,}개", transform=ax.transAxes,
                ha="right", va="top", color=INK2, fontsize=11)
    save(fig, os.path.join(a.fig, "fig1_조향값분포.png"))

    # ------------------------------------------------ 그림 2: 시험셋 오차 막대
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.8), sharey=True)
    labels = keys
    for ax, met, title in [(axs[0], "mae", "전체 구간 MAE"), (axs[1], "mae_curve", "곡선 구간 MAE")]:
        mus = [ms([r["test"][met] for r in runs[k]]) for k in keys]
        cols = [BASE_GRAY if k == keys[0] else BEST_BLUE if k == last else "#b7d3f6" for k in keys]
        xs = np.arange(len(keys))
        ax.bar(xs, [m for m, _ in mus], yerr=[s for _, s in mus], color=cols, width=0.62,
               capsize=4, error_kw=dict(ecolor=INK2, lw=1.2))
        for x_, (m, s) in zip(xs, mus):
            ax.text(x_, m + s + 0.004, f"{m:.3f}", ha="center", color=INK, fontsize=10.5)
        ax.axhline(ref[met], color=MUTED, ls="--", lw=1.2)
        ax.set_xticks(xs, labels)
        ax.set_title(title, loc="left", color=INK, fontsize=13)
        ax.grid(axis="x", visible=False)
    axs[0].set_ylabel("시험셋 MAE (낮을수록 좋음)")
    va_ = [r["test"]["mae_curve"] for r in runs[last]]; vb_ = [r["test"]["mae_curve"] for r in runs[keys[0]]]
    p_ad = stats.ttest_ind(va_, vb_, equal_var=False)[1]
    axs[1].text(0.98, 0.04, f"A → {last}: {(np.mean(va_)/np.mean(vb_)-1)*100:+.0f}% (p={p_ad:.3f})",
                transform=axs[1].transAxes, ha="right", color=INK, fontsize=11,
                bbox=dict(boxstyle="round,pad=0.3", fc="#fcfcfb", ec="#d6d5cf"))
    fig.text(0.01, -0.06, "  ".join(f"{k}: {names[k]}" for k in keys) + f"   |   막대: {n_seeds}회 평균, 오차막대: ±1 표준편차, 점선: 항상 직진(0)만 출력할 때",
             color=INK2, fontsize=10)
    save(fig, os.path.join(a.fig, "fig2_시험오차비교.png"))

    # ------------------------------------------------ 그림 3: 시간에 따른 예측 비교
    def median_run(k):
        rs = sorted(runs[k], key=lambda r: r["test"]["mae"])
        return rs[len(rs) // 2]
    rA, rE = median_run(keys[0]), median_run(last)
    blocks = te // 100
    best_b, best_c = None, -1
    for b in np.unique(blocks):
        c = (np.abs(yte[blocks == b]) >= CURVE_TH).sum()
        if c > best_c: best_b, best_c = b, c
    m = blocks == best_b
    t = np.arange(m.sum()) * 0.117   # 기록 간격 약 0.117초
    pE = np.array(rE["pred_test"])
    fig, ax = plt.subplots(figsize=(11, 4.6))
    ax.plot(t, yte[m], color=INK, lw=2, label="실제 조향(사람)")
    ax.plot(t, np.array(rA["pred_test"])[m], color=BASE_GRAY, lw=2, label=f"A. 기준 모델")
    ax.plot(t, pE[m], color=SERIES[0], lw=2, label=f"{last}. 최종 모델")
    ax.plot(t, ema_sequence(pE, alpha)[m], color=POST, lw=2, label=f"{last}. 최종 모델 + 후처리")
    ax.axhline(0, color="#d6d5cf", lw=1)
    ax.set_xlabel("시간 (초)")
    ax.set_ylabel("조향값")
    ax.set_title("곡선이 가장 많은 시험 구간에서 예측 비교 (중간 성능 시드)", loc="left", color=INK, fontsize=13)
    ax.legend(loc="lower left", ncol=4, fontsize=10, bbox_to_anchor=(0, -0.32))
    save(fig, os.path.join(a.fig, "fig3_예측시계열.png"))

    # ------------------------------------------------ 그림 4: 후처리 효과
    fig, axs = plt.subplots(1, 2, figsize=(10, 4.2))
    pairs = [("전체 MAE", [r["test"]["mae"] for r in runs[last]], [m_["mae"] for m_ in post]),
             ("흔들림 (프레임 간 조향 변화)", jit_e, jit_p)]
    for ax, (title, v1, v2) in zip(axs, pairs):
        mu = [np.mean(v1), np.mean(v2)]; sd = [np.std(v1, ddof=1), np.std(v2, ddof=1)]
        ax.bar([0, 1], mu, yerr=sd, color=[SERIES[0], POST], width=0.55, capsize=4, error_kw=dict(ecolor=INK2))
        for x_, mm, ss in zip([0, 1], mu, sd):
            ax.text(x_, mm + ss + max(mu) * 0.02, f"{mm:.4f}", ha="center", color=INK, fontsize=10.5)
        ax.set_ylim(0, max(np.array(mu) + np.array(sd)) * 1.2)
        ax.set_xticks([0, 1], ["후처리 없음", f"EMA α={alpha}"])
        ax.set_title(title, loc="left", color=INK, fontsize=13)
        ax.grid(axis="x", visible=False)
    axs[0].set_ylabel("시험셋 값 (낮을수록 좋음)")
    save(fig, os.path.join(a.fig, "fig4_후처리효과.png"))
    print(open(os.path.join(a.fig, "results.md")).read())


if __name__ == "__main__":
    main()
