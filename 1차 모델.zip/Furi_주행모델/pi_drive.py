"""라즈베리파이 4B에서 Furi를 학습된 모델로 주행시키는 예시 루프.

카메라 -> 전처리 -> 모델(조향 예측) -> 후처리(EMA·범위 제한) -> MG90S 4개(4륜 구동)
전방 거리 센서가 가까운 장애물을 감지하면 모델 출력과 관계없이 정지한다.

※ 이 스크립트는 작업 공간에서 실제 하드웨어 없이 작성한 예시이며, Furi에서
   아직 실행해 보지 않았다. MOTOR_PINS의 빈 핀 번호와 read_front_mm()는
   팀 배선에 맞게 채워야 한다. 서보 펄스는 pigpio로 낸다(sudo pigpiod 먼저 실행).
사용법: python pi_drive.py --model model_D.pt   (E 모델이면 --bn 추가)
"""
import argparse, time
import numpy as np
import torch
from PIL import Image

from furi_model import (SteerNet, preprocess, to_tensor, SteerSmoother,
                        steer_to_wheels, wheels_to_servo_us)

STOP_MM = 150   # 전방 장애물 정지 거리

# 바퀴별 GPIO(BCM 번호). 발표자료의 GPIO 12(좌), 13(우)을 앞바퀴로 가정했다.
# 뒷바퀴 핀은 실제 배선에 맞게 넣을 것. None이면 그 바퀴는 건너뛴다.
MOTOR_PINS = {"FL": 12, "FR": 13, "RL": None, "RR": None}
_pi = None


def read_front_mm() -> int:
    """TODO: 전방 VL53L0X 거리(mm) 반환. 센서 3개는 XSHUT 핀으로 주소를 바꿔 써야 한다."""
    return 9999


def set_motors(left: float, right: float):
    """좌·우 속도(0~1)를 MG90S 4개의 서보 펄스로 출력. 0, 0이면 정지."""
    global _pi
    if _pi is None:
        import pigpio
        _pi = pigpio.pi()
    pulses = wheels_to_servo_us(left, right)
    for wheel, pin in MOTOR_PINS.items():
        if pin is not None:
            _pi.set_servo_pulsewidth(pin, pulses[wheel])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--bn", action="store_true", help="배치정규화 모델(E)일 때")
    ap.add_argument("--alpha", type=float, default=0.2)
    ap.add_argument("--speed", type=float, default=0.35)
    a = ap.parse_args()

    torch.set_num_threads(4)
    model = SteerNet(bn=a.bn, dropout=0.3 if a.bn else 0.0)
    model.load_state_dict(torch.load(a.model, map_location="cpu", weights_only=True))
    model.eval()
    smooth = SteerSmoother(alpha=a.alpha, limit=0.8)

    from picamera2 import Picamera2          # 라즈베리파이 카메라 라이브러리
    cam = Picamera2()
    cam.configure(cam.create_preview_configuration(main={"size": (320, 160), "format": "RGB888"}))
    cam.start()
    try:
        while True:
            t0 = time.time()
            if read_front_mm() < STOP_MM:            # 안전 정지가 모델보다 우선
                set_motors(0, 0); smooth.reset(); time.sleep(0.05); continue
            frame = Image.fromarray(cam.capture_array())
            with torch.no_grad():
                raw = float(model(to_tensor(preprocess(frame)[None]))[0])
            steer = smooth(raw)
            set_motors(*steer_to_wheels(steer, base_speed=a.speed))
            time.sleep(max(0, 0.1 - (time.time() - t0)))   # 약 10Hz
    finally:
        set_motors(0, 0)
        if _pi is not None:
            for pin in MOTOR_PINS.values():
                if pin is not None:
                    _pi.set_servo_pulsewidth(pin, 0)   # 펄스 끄기
            _pi.stop()
        cam.stop()


if __name__ == "__main__":
    main()
