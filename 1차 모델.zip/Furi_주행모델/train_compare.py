"""공개 주행 데이터로 기준 모델과 단계별 개선 모델을 학습하고 비교한다.

사용법: python train_compare.py --data <driving_log.csv가 있는 폴더> --out results
각 설정을 서로 다른 시드로 여러 번 학습해 평균과 표준편차를 낸다.
"""
import argparse, json, os, time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from PIL import Image

from furi_model import SteerNet, preprocess, to_tensor, ema_sequence

SIDE_CORRECTION = 0.2     # 좌/우 카메라 영상에 더하고 빼는 조향 보정값
ZERO_TH = 0.01            # |조향| < 이 값이면 '직진' 프레임
CURVE_TH = 0.05           # |조향| >= 이 값이면 '곡선' 프레임

# 누적 방식: 아래로 갈수록 앞 단계의 개선을 모두 포함
CONFIGS = [
    dict(key="A", name="기준 모델",          cams=1, aug=False, balance=False, bn=False),
    dict(key="B", name="+ 데이터 증강",       cams=1, aug=True,  balance=False, bn=False),
    dict(key="C", name="+ 좌우 카메라",       cams=3, aug=True,  balance=False, bn=False),
    dict(key="D", name="+ 분포 균형화",       cams=3, aug=True,  balance=True,  bn=False),
    dict(key="E", name="+ 배치정규화·드롭아웃", cams=3, aug=True,  balance=True,  bn=True),
]


# ---------------------------------------------------------------- 데이터
def load_cache(data_dir, cache):
    if os.path.exists(cache):
        z = np.load(cache)
        return z["X"], z["y"]
    log = pd.read_csv(os.path.join(data_dir, "driving_log.csv"), header=None)
    X = np.zeros((len(log), 3, 48, 128, 3), np.uint8)   # center, left, right
    for i, row in log.iterrows():
        for c in range(3):
            fn = row[c].strip().split("/")[-1]
            X[i, c] = preprocess(Image.open(os.path.join(data_dir, "IMG", fn)))
    y = log[3].astype(np.float32).values
    np.savez(cache, X=X, y=y)
    return X, y


def block_split(n, block=100, seed=0, frac=(0.7, 0.15, 0.15)):
    """연속 프레임은 거의 같은 장면이므로, 100프레임 덩어리 단위로 나눠
    학습·검증·시험 사이에 장면이 새지 않게 한다."""
    nb = int(np.ceil(n / block))
    order = np.random.RandomState(seed).permutation(nb)
    n_tr, n_va = round(nb * frac[0]), round(nb * frac[1])
    parts = [order[:n_tr], order[n_tr:n_tr + n_va], order[n_tr + n_va:]]
    idx = [np.concatenate([np.arange(b * block, min((b + 1) * block, n)) for b in sorted(p)]) for p in parts]
    return idx  # train, val, test (각각 시간순)


def expand_train(X, y, idx, cams):
    """학습용 (이미지, 조향) 쌍. cams=3이면 좌우 카메라를 보정값과 함께 추가."""
    imgs, labels, is_zero = [X[idx, 0]], [y[idx]], [np.abs(y[idx]) < ZERO_TH]
    if cams == 3:
        imgs += [X[idx, 1], X[idx, 2]]
        labels += [y[idx] + SIDE_CORRECTION, y[idx] - SIDE_CORRECTION]
        is_zero += [np.abs(y[idx]) < ZERO_TH] * 2
    return (np.concatenate(imgs), np.clip(np.concatenate(labels), -1, 1).astype(np.float32),
            np.concatenate(is_zero))


def balanced_indices(is_zero, rng, zero_share=0.3):
    """원래 조향이 0인 프레임을 매 에폭 무작위로 덜어내 전체의 zero_share만 남긴다."""
    nz, z = np.where(~is_zero)[0], np.where(is_zero)[0]
    keep = int(len(nz) * zero_share / (1 - zero_share))
    return np.concatenate([nz, rng.choice(z, min(keep, len(z)), replace=False)])


def augment(xb, yb, gen):
    """배치 단위 증강: 좌우 반전(조향 부호 반전), 밝기 변화, 상하 이동."""
    n = xb.shape[0]
    flip = torch.rand(n, generator=gen) < 0.5
    xb[flip] = xb[flip].flip(-1)
    yb = torch.where(flip, -yb, yb)
    bright = torch.empty(n, 1, 1, 1).uniform_(0.6, 1.3, generator=gen)
    xb = ((xb + 1) * bright - 1).clamp(-1, 1)
    shift = int(torch.randint(-3, 4, (1,), generator=gen))
    xb = torch.roll(xb, shifts=shift, dims=2)
    return xb, yb


# ---------------------------------------------------------------- 학습/평가
@torch.no_grad()
def predict(model, Xc, bs=256):
    model.eval()
    return np.concatenate([model(to_tensor(Xc[i:i + bs])).numpy() for i in range(0, len(Xc), bs)])


def metrics(y, p, blocks):
    err = np.abs(p - y)
    curve, straight = np.abs(y) >= CURVE_TH, np.abs(y) < ZERO_TH
    # 흔들림: 연속한 두 프레임 사이 예측 조향값 변화량 평균 (같은 덩어리 안에서만)
    same = blocks[1:] == blocks[:-1]
    jitter = np.abs(np.diff(p))[same].mean()
    return dict(mae=float(err.mean()), rmse=float(np.sqrt((err ** 2).mean())),
                mae_curve=float(err[curve].mean()), mae_straight=float(err[straight].mean()),
                jitter=float(jitter))


def train_one(cfg, seed, X, y, tr, va, epochs, patience, log):
    torch.manual_seed(seed)
    rng, gen = np.random.RandomState(seed), torch.Generator().manual_seed(seed)
    Xtr, ytr, zero = expand_train(X, y, tr, cfg["cams"])
    model = SteerNet(bn=cfg["bn"], dropout=0.3 if cfg["bn"] else 0.0)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    lossf = nn.MSELoss()
    hist, best, best_state, wait = [], 1e9, None, 0
    t0 = time.time()
    for ep in range(1, epochs + 1):
        model.train()
        sel = balanced_indices(zero, rng) if cfg["balance"] else np.arange(len(ytr))
        rng.shuffle(sel)
        tot = 0.0
        for i in range(0, len(sel), 64):
            b = sel[i:i + 64]
            xb, yb = to_tensor(Xtr[b]), torch.from_numpy(ytr[b])
            if cfg["aug"]:
                xb, yb = augment(xb, yb, gen)
            loss = lossf(model(xb), yb)
            opt.zero_grad(); loss.backward(); opt.step()
            tot += loss.item() * len(b)
        val_mae = float(np.abs(predict(model, X[va, 0]) - y[va]).mean())
        hist.append(dict(epoch=ep, train_loss=tot / len(sel), val_mae=val_mae))
        if val_mae < best - 1e-4:
            best, wait = val_mae, 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            wait += 1
        log(f"  [{cfg['key']} seed{seed}] ep{ep:02d} train_mse={tot/len(sel):.4f} val_mae={val_mae:.4f}")
        if wait >= patience:
            break
    model.load_state_dict(best_state)
    return model, hist, time.time() - t0, len(sel)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="results")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--patience", type=int, default=6)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    torch.set_num_threads(os.cpu_count())
    logf = open(os.path.join(a.out, "train_log.txt"), "a")
    def log(s):
        print(s, flush=True); logf.write(s + "\n"); logf.flush()

    X, y = load_cache(a.data, os.path.join(a.out, "cache.npz"))
    tr, va, te = block_split(len(y))
    blocks_te, blocks_va = te // 100, va // 100
    json.dump(dict(train=tr.tolist(), val=va.tolist(), test=te.tolist()), open(os.path.join(a.out, "split.json"), "w"))
    log(f"frames={len(y)} train={len(tr)} val={len(va)} test={len(te)} "
        f"test_curve={int((np.abs(y[te])>=CURVE_TH).sum())}")

    # 참고선: 항상 0(직진)만 출력하는 경우
    ref = metrics(y[te], np.zeros(len(te)), blocks_te)
    json.dump(ref, open(os.path.join(a.out, "ref_zero.json"), "w"), indent=1)

    for cfg in CONFIGS:
        if a.only and cfg["key"] not in a.only:
            continue
        for seed in range(a.seeds):
            path = os.path.join(a.out, f"run_{cfg['key']}_{seed}.json")
            if os.path.exists(path):
                continue
            model, hist, sec, n_ep = train_one(cfg, seed, X, y, tr, va, a.epochs, a.patience, log)
            p_te, p_va = predict(model, X[te, 0]), predict(model, X[va, 0])
            res = dict(cfg=cfg, seed=seed, hist=hist, train_sec=sec, samples_per_epoch=n_ep,
                       test=metrics(y[te], p_te, blocks_te), val=metrics(y[va], p_va, blocks_va),
                       pred_test=p_te.tolist(), pred_val=p_va.tolist())
            json.dump(res, open(path, "w"))
            torch.save(model.state_dict(), os.path.join(a.out, f"model_{cfg['key']}_{seed}.pt"))
            log(f"DONE {cfg['key']} seed{seed}: test {res['test']}  ({sec:.0f}s)")


if __name__ == "__main__":
    main()
