"""Furi 주행 모델: 카메라 영상 -> 모델 -> 후처리 -> 모터.

학습(train_compare.py)과 라즈베리파이 주행(pi_drive.py)이 같은 전처리와
모델 구조를 쓰도록 이 파일 하나에 모아 두었다.
"""
import numpy as np
import torch
import torch.nn as nn
from PIL import Image

# ---------------------------------------------------------------- 전처리
IN_H, IN_W = 48, 128          # 모델 입력 크기 (라즈베리파이 연산량을 고려해 작게)
CROP_TOP, CROP_BOTTOM = 0.375, 0.156   # 하늘(위 37.5%)과 차체(아래 15.6%) 잘라냄


def preprocess(img: Image.Image) -> np.ndarray:
    """PIL 이미지 -> (IN_H, IN_W, 3) uint8. 위아래를 자르고 축소."""
    w, h = img.size
    top, bottom = int(h * CROP_TOP), int(h * (1 - CROP_BOTTOM))
    img = img.crop((0, top, w, bottom)).resize((IN_W, IN_H), Image.BILINEAR)
    return np.asarray(img.convert("RGB"), dtype=np.uint8)


def to_tensor(batch_uint8: np.ndarray) -> torch.Tensor:
    """(N,H,W,3) uint8 -> (N,3,H,W) float, -1~1 범위."""
    x = torch.from_numpy(np.ascontiguousarray(batch_uint8).copy()).permute(0, 3, 1, 2).float()
    return x / 127.5 - 1.0


# ---------------------------------------------------------------- 모델
class SteerNet(nn.Module):
    """NVIDIA PilotNet을 축소한 조향 회귀 CNN.

    bn=True면 각 합성곱 뒤에 배치정규화, 완전연결층에 드롭아웃을 넣는다.
    """

    def __init__(self, bn: bool = False, dropout: float = 0.0):
        super().__init__()

        def block(cin, cout, k, s):
            layers = [nn.Conv2d(cin, cout, k, s, padding=k // 2)]
            if bn:
                layers.append(nn.BatchNorm2d(cout))
            layers.append(nn.ELU())
            return layers

        self.features = nn.Sequential(
            *block(3, 24, 5, 2),    # 24x64
            *block(24, 36, 5, 2),   # 12x32
            *block(36, 48, 5, 2),   # 6x16
            *block(48, 64, 3, 1),
            *block(64, 64, 3, 2),   # 3x8
        )
        self.head = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(dropout),
            nn.Linear(64 * 3 * 8, 100), nn.ELU(),
            nn.Dropout(dropout),
            nn.Linear(100, 50), nn.ELU(),
            nn.Linear(50, 10), nn.ELU(),
            nn.Linear(10, 1),
        )

    def forward(self, x):
        return self.head(self.features(x)).squeeze(1)


# ---------------------------------------------------------------- 후처리
class SteerSmoother:
    """지수이동평균(EMA)으로 프레임마다 튀는 조향값을 부드럽게 만들고
    최대 조향 범위를 제한한다. alpha가 클수록 새 예측을 더 많이 반영."""

    def __init__(self, alpha: float = 0.5, limit: float = 1.0):
        self.alpha, self.limit, self.prev = alpha, limit, None

    def reset(self):
        self.prev = None

    def __call__(self, steer: float) -> float:
        s = steer if self.prev is None else self.alpha * steer + (1 - self.alpha) * self.prev
        s = float(np.clip(s, -self.limit, self.limit))
        self.prev = s
        return s


def ema_sequence(pred: np.ndarray, alpha: float) -> np.ndarray:
    sm = SteerSmoother(alpha)
    return np.array([sm(float(p)) for p in pred])


def steer_to_wheels(steer: float, base_speed: float = 0.35, gain: float = 0.5):
    """조향값(-1 왼쪽 ~ +1 오른쪽)을 좌측·우측 바퀴 속도(0~1)로 변환.
    Furi는 4륜 구동이므로 좌측 앞·뒤 두 바퀴는 left, 우측 두 바퀴는 right를 같이 받는다
    (좌우 속도 차이로 회전하는 스키드 조향)."""
    left = np.clip(base_speed * (1 + gain * steer), 0.0, 1.0)
    right = np.clip(base_speed * (1 - gain * steer), 0.0, 1.0)
    return float(left), float(right)


# ---------------------------------------------------------------- 4륜 MG90S 출력
# MG90S 360도 연속회전형 기준: 1500us 정지, 1500±500us에서 최고 속도(정·역).
# 좌우 모터가 거울상으로 장착돼 있어 전진할 때 한쪽은 -1, 다른 쪽은 +1 방향으로 돈다
# (발표자료의 'GPIO 12번 -1 / GPIO 13번 +1'). 부호와 정지 펄스는 실물에서 확인할 것.
SERVO_STOP_US, SERVO_SPAN_US = 1500, 500
SIDE_SIGN = {"left": -1, "right": +1}


def wheels_to_servo_us(left: float, right: float, stop_us: int = SERVO_STOP_US,
                       span_us: int = SERVO_SPAN_US, side_sign=SIDE_SIGN) -> dict:
    """좌·우 속도(0~1, 음수면 후진)를 바퀴 4개의 서보 펄스폭(us)으로 변환."""
    l = int(round(stop_us + side_sign["left"] * np.clip(left, -1, 1) * span_us))
    r = int(round(stop_us + side_sign["right"] * np.clip(right, -1, 1) * span_us))
    return {"FL": l, "RL": l, "FR": r, "RR": r}
